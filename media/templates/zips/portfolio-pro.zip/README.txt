Portfolio theme — preview templates/index.html
Integrate by copying template files to your Django app templates and static to static/portfolio/.