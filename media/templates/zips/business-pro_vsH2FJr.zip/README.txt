Restaurant theme — preview templates/index.html
Copy /templates -> your Django templates, and /static -> static/theme_name for production.